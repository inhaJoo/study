package com.bandisnc.common.dto;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@Getter
@Setter
@SuperBuilder
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class CmUserDTO implements Serializable {

    private String oid;
    private String userId;
    private String name;
    private String email;
}
