package com.bandisnc.common.manage.service;

import java.io.Serializable;

public interface IManageService <D, ID extends Serializable> {
    D get(ID oid);

    D
    add(D dto);

    D edit(D dto);

    D remove(ID oid);
}
