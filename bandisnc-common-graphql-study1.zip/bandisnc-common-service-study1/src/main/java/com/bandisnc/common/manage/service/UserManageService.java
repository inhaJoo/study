package com.bandisnc.common.manage.service;

import com.bandisnc.common.dto.CmUserDTO;

public interface UserManageService extends IManageService<CmUserDTO, String>{
}
