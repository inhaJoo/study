package com.bandisnc.graphql.common.service.impl;

import com.bandisnc.common.dto.CmUserDTO;
import com.bandisnc.common.manage.service.UserManageService;
import com.bandisnc.graphql.common.dto.User;
import com.bandisnc.graphql.common.dto.UserAdd;
import com.bandisnc.graphql.common.service.UserGraphqlService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service("defaultUserGraphqlService")
public class DefaultUserGraphqlService implements UserGraphqlService  {

    //@Resource : Name으로 Bean을 지정한다.(필드/메서드에만 적용 가능)
    @Resource(name="${bean.cm.user.manage.service:userJPAManageService}")
    protected UserManageService userManageService;

    public User get(String oid) {
        return null;
    }

    public User add(UserAdd input) {
        CmUserDTO DTO = new CmUserDTO();
        DTO.setOid(input.getOid());
        DTO.setUserId(input.getUserId());
        DTO.setName(input.getName());
        DTO.setEmail(input.getEmail());

        userManageService.add(DTO);

        User user = new User();
        user.setOid(DTO.getOid());

        return user;
    }
}
