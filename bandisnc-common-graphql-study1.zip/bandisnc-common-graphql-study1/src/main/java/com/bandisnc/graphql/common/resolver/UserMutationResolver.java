package com.bandisnc.graphql.common.resolver;

import com.bandisnc.graphql.common.dto.User;
import com.bandisnc.graphql.common.dto.UserAdd;
import com.bandisnc.graphql.common.dto.UserEdit;
import com.bandisnc.graphql.common.service.UserGraphqlService;
import graphql.kickstart.tools.GraphQLMutationResolver;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class UserMutationResolver implements GraphQLMutationResolver {

    @Resource(name="${bean.graphql.user.service:defaultUserGraphqlService}")
    protected UserGraphqlService userGraphqlService;


    public User addUser(UserAdd user) {
        //todo 사용자 등록로직.....

        System.out.println("화면으로부터 받아온값");
        System.out.println(user.getOid());
        System.out.println(user.getUserId());
        System.out.println(user.getName());

        return userGraphqlService.add(user);
    }


    public User editUser(UserEdit user) {
        //todo 사용자 등록로직.....

        System.out.println("화면으로부터 받아온값");
        System.out.println(user.getOid());
        System.out.println(user.getUserId());
        System.out.println(user.getName());

        User user1 = new User();

        user1.setOid(user.getOid());
        user1.setUserId(user.getUserId());
        user1.setName(user.getName());
        user1.setEmail(user.getEmail());

        return user1;
    }

    public String removeUser(String oid) {
        System.out.println(oid + "인값을 삭제합니다");

        User user1 = new User();

        user1.setOid("123");
        user1.setUserId("kimbs");
        user1.setName("김병수");
        user1.setEmail("kimbs@bandisnc.com");


        return "1234";
    }
}
