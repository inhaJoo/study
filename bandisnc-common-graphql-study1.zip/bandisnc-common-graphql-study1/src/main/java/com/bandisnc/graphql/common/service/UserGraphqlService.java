package com.bandisnc.graphql.common.service;

import com.bandisnc.graphql.common.dto.User;
import com.bandisnc.graphql.common.dto.UserAdd;

public interface UserGraphqlService {
    User get(String oid);

    User add(UserAdd input);
}
