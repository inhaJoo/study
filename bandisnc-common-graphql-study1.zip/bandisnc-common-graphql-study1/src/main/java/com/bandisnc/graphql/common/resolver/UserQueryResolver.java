package com.bandisnc.graphql.common.resolver;

import com.bandisnc.graphql.common.dto.User;
import com.bandisnc.graphql.common.service.UserGraphqlService;
import graphql.kickstart.tools.GraphQLQueryResolver;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

// bandisnc-common-service-study
@Component
public class UserQueryResolver implements GraphQLQueryResolver {

    @Resource(name = "${bean.graphql.user.service:defaultUserGraphqlService}")
    protected UserGraphqlService userGraphqlService;

    public User getUser(String oid) {
        User user1 = new User();

        System.out.println("사용자 정보를 갖고갑니다.");

        userGraphqlService.get(oid);
        return user1;
    }

}
