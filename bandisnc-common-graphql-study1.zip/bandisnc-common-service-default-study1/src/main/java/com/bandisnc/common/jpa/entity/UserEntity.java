package com.bandisnc.common.jpa.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Getter
@Setter
@Entity
@Table(name="bds_cm_user")
public class UserEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Size(min=1, max=100)
    @Column(name="oid", length=100,  nullable = false)
    private String oid;

    /** 사용자 아이디 */
    @Size(min=1, max=100)
    @Column(name="user_id", length=100, unique=true, nullable = false)
    private String userId;

    @Size(min=1, max=100)
    @Column(name="name", length=100)
    private String name;

    @Size(min=1, max=100)
    @Column(name="email", length=100)
    private String email;

    @Size(min=1, max=100)
    @Column(name="status", length=100)
    private String status;

}
