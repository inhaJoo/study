package com.bandisnc.common.manage.service;


import com.bandisnc.common.dto.CmUserDTO;
import com.bandisnc.common.jpa.entity.UserEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;

@Service("userJPAManageService")
public class UserJPAManageService implements UserManageService {

    @Autowired
    EntityManager entityManager;


    @Override
    public CmUserDTO get(String oid) {
        // entityManager.find()


        return null;
    }

    @Override
    @Transactional
    public CmUserDTO add(CmUserDTO dto) {
        UserEntity entity = new UserEntity();
        entity.setOid(dto.getOid());
        entity.setUserId(dto.getUserId());
        entity.setName(dto.getName());
        entity.setEmail(dto.getEmail());

        entityManager.persist(entity);

        return dto;

    }

    @Override
    public CmUserDTO edit(CmUserDTO dto) {
        return null;
    }

    @Override
    public CmUserDTO remove(String oid) {
        return null;
    }
}
