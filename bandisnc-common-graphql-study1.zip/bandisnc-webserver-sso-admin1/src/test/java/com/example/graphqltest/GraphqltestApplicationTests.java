package com.example.graphqltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphqltestApplicationTests {

    @Test
    void contextLoads() {
    }

}
